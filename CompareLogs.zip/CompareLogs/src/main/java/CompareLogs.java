import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class CompareLogs {
    static List<String> STR_TO_EXCLUDE =  Arrays.asList("Check the object properties",
            "Check the object properties",
            "Check List of Values",
            "Check for Isolated Table",
            "Check Business Filter",
            "Check Table Primary Key",
            "Check for Undefined Cardinality",
            "Check Query",
            "Check Business Object Expression");

    static String DOUBLE_SPACE = "  ";
    static String PREFIX= " fdb_core_";
    static String PREFIX_DB ="DB_ANALYTICS.CORE.";

    public static void main(String[] args) throws IOException {
        String fileDEV = "src/main/resources/old.txt";
        ArrayList<String> DEVArray = new ArrayList<String>();
        writeLogsFromFileToArray(DEVArray, fileDEV);

        String fileQA = "src/main/resources/new.txt";
        ArrayList<String> QAArray = new ArrayList<String>();
        writeLogsFromFileToArray(QAArray, fileQA);

        //Parse QA file
        ArrayList<String> errorsAndWarnings = new ArrayList<String>();
        for (String line : QAArray) {
            if (line.contains("ERROR") || line.contains("WARNING")) {
                errorsAndWarnings.add(line);
            }
        }

        //write only new (don`t included in DEV file) errors or warnings from QA file to new file "new_errors_and_warnings"
        writeNewLogQAToFile(errorsAndWarnings, DEVArray, "new_errors_and_warnings");

        //write pairs logs and number of line from DEV and QA files
        writeToFileCompareOfArrays(QAArray, DEVArray, "dif_logs");
    }

    public static ArrayList writeLogsFromFileToArray(ArrayList<String> listLogs, String nameFile) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(nameFile));
        String currentLine = "";
        while (currentLine != null) {
            currentLine = reader.readLine();
            if (currentLine != null) {
                //currentLine=currentLine.toLowerCase();
                currentLine = currentLine.replaceAll("\t", " ");
                currentLine=currentLine.replaceAll(PREFIX, " ");
                currentLine=currentLine.replaceAll(PREFIX_DB, "");

                for(String string: STR_TO_EXCLUDE) {
                    currentLine = currentLine.replaceAll(string, "");
                }

                while (currentLine.contains(DOUBLE_SPACE)) {
                    currentLine = currentLine.replaceAll(DOUBLE_SPACE, " ");
                }
                if ((currentLine.contains(StatusType.ERROR.toString()) || currentLine.contains(StatusType.OK.toString()) || currentLine.contains(StatusType.WARNING.toString()))) {
                    listLogs.add(currentLine.trim());
                } else if (!(currentLine.contains(StatusType.ERROR.toString()) || currentLine.contains(StatusType.OK.toString()) || currentLine.contains(StatusType.WARNING.toString()))) {
                    String newLine = listLogs.get(listLogs.size() - 1) + " " + currentLine.trim();
                    listLogs.remove(listLogs.size() - 1);
                    listLogs.add(newLine);
                }
            }
        }
        reader.close();
        return listLogs;
    }

    public static void writeNewLogQAToFile(ArrayList<String> listErrorOrWarningFromQAFile, ArrayList<String> listDEVLogs, String partOfNameFile) throws IOException {
        for (int i = 0; i < listErrorOrWarningFromQAFile.size(); i++) {
            boolean needToInclude = true;
            for (int j = 0; j < listDEVLogs.size(); j++) {
                if (listErrorOrWarningFromQAFile.get(i).equalsIgnoreCase(listDEVLogs.get(j))) {
                    needToInclude = false;
                    break;
                }
            }
            if (needToInclude) {
                String newFileName = createNewFile(partOfNameFile);
                PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(newFileName, true)));
                writer.println(listErrorOrWarningFromQAFile.get(i));
                writer.close();
            }
        }
    }

    public static String createNewFile(String partOfNameFile) throws IOException {
        String currentDateTime = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
        String fileName = currentDateTime + "_" + partOfNameFile + ".txt";
        File newFile = new File(fileName);
        newFile.createNewFile();
        return newFile.toString();
    }

    public static void writeToFileCompareOfArrays(ArrayList<String> QAArray, ArrayList<String> DEVArray, String partOfNameFile) throws IOException {
        String newFileName = createNewFile(partOfNameFile);
        String flag = checkTheDiffSizeOfArrays(QAArray, DEVArray);
        if (flag.equals("SIMULAR")) {
            for (int i = 0; i < QAArray.size(); i++) {
                if (!QAArray.get(i).equalsIgnoreCase(DEVArray.get(i))) {
                    try {
                        PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(newFileName, true)));
                        writer.println("Line`s number: " + Integer.toString(i + 1));
                        writer.println("Line from DEV file: " + DEVArray.get(i));
                        writer.println("Line from QA file: " + QAArray.get(i));
                        writer.close();
                    } catch (IOException e) {
                        System.out.println("BIG FAIL with tries writing diff logs");
                    }
                } else {
                    System.out.println("Lines with number " + Integer.toString(i + 1) + " is equal");
                }
            }
        } else if (flag.equals("QA")) {
            for (int i = 0; i < DEVArray.size(); i++) {
                if (!DEVArray.get(i).equalsIgnoreCase(QAArray.get(i))) {
                    try {
                        PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(newFileName, true)));
                        writer.println("Line`s number: " + Integer.toString(i + 1));
                        writer.println("Line from DEV file: " + DEVArray.get(i));
                        writer.println("Line from QA file: " + QAArray.get(i));
                        writer.close();
                    } catch (IOException e) {
                        System.out.println("BIG FAIL with tries writing diff logs");
                    }
                } else {
                    System.out.println("Lines with number " + Integer.toString(i + 1) + " is equal");
                }
            }
            for (int i = QAArray.size() - 1; i < DEVArray.size(); i++) {
                try {
                    PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(newFileName, true)));
                    writer.println("Line`s number: " + Integer.toString(i + 1));
                    writer.println("Line from DEV file: is empty");
                    writer.println("Line from QA file: " + QAArray.get(i));
                    writer.close();
                } catch (IOException e) {
                    System.out.println("BIG FAIL with tries writing diff logs");
                }

            }
        }

        if (flag.equals("DEV")) {
            for (int i = 0; i < QAArray.size(); i++) {
                if (!QAArray.get(i).equalsIgnoreCase(DEVArray.get(i))) {
                    try {
                        PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(newFileName, true)));
                        writer.println("Line`s number: " + Integer.toString(i + 1));
                        writer.println("Line from DEV file: " + DEVArray.get(i));
                        writer.println("Line from QA file: " + QAArray.get(i));
                        writer.close();
                    } catch (IOException e) {
                        System.out.println("BIG FAIL with tries writing diff logs");
                    }
                } else {
                    System.out.println("Lines with number " + Integer.toString(i + 1) + " is equal");
                }
            }
            for (int i = QAArray.size() - 1; i < DEVArray.size(); i++) {
                try {
                    PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(newFileName, true)));
                    writer.println("Line`s number: " + Integer.toString(i + 1));
                    writer.println("Line from DEV file: " + DEVArray.get(i));
                    writer.println("Line from QA file: is empty");
                    writer.close();
                } catch (IOException e) {
                    System.out.println("BIG FAIL with tries writing diff logs");
                }
            }
        }
    }

    public static String checkTheDiffSizeOfArrays(ArrayList<String> QAArray, ArrayList<String> DEVArray) {
        String flag = "";
        if (QAArray.size() > DEVArray.size()) {
            flag = "QA";
        } else if (QAArray.size() < DEVArray.size()) {
            flag = "DEV";
        } else if (QAArray.size() == DEVArray.size()) {
            flag = "SIMULAR";
        }
        return flag;
    }

}
