public enum StatusType {
    OK("OK"),
    ERROR("ERROR"),
    WARNING("WARNING")
    ;

    private final String text;

    /**
     * @param text
     */
    StatusType(final String text) {
        this.text = text;
    }

    /* (non-Javadoc)
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return text;
    }
}